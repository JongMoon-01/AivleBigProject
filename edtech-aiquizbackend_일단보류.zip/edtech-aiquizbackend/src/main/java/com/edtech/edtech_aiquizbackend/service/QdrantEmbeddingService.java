package com.edtech.edtech_aiquizbackend.service;

import com.edtech.edtech_aiquizbackend.domain.aiquiz.AIQuiz;
import com.edtech.edtech_aiquizbackend.domain.aiquiz.QuizType;
import com.edtech.edtech_aiquizbackend.domain.summary.Summary;
import com.edtech.edtech_aiquizbackend.domain.summary.repository.SummaryRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.theokanning.openai.completion.chat.*;
import com.theokanning.openai.service.OpenAiService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor
public class QdrantEmbeddingService {
    private final OpenAiService openAiService;
    private final QdrantClientService qdrantClientService;
    private final SummaryRepository summaryRepository;

    public String summarizeTextAndSaveToQdrant(String input) {
        String topic = extractTopic(input);

        ChatCompletionRequest request = ChatCompletionRequest.builder()
                .model("gpt-3.5-turbo")
                .messages(List.of(
                        new ChatMessage("system", "다음 자막 텍스트를 간결하게 요약해주세요."),
                        new ChatMessage("user", input)
                ))
                .temperature(0.7)
                .build();

        String summary = openAiService.createChatCompletion(request)
                .getChoices().get(0).getMessage().getContent().trim();

        qdrantClientService.upsertSummaryToQdrant(summary);
        System.out.println("🧠 요약 결과: " + summary);
        System.out.println("🧠 주제: " + topic);
        return summary;
    }

    public List<AIQuiz> generateQuiz(String summarizedText, Summary summary) {
        ChatCompletionRequest request = ChatCompletionRequest.builder()
                .model("gpt-3.5-turbo")
                .messages(List.of(
                        new ChatMessage("system", "다음 요약 내용을 기반으로 퀴즈 3개를 JSON 배열로 생성해주세요. 각 항목은 quiz_text, answer_text, quiz_type 포함."),
                        new ChatMessage("user", summarizedText)
                ))
                .temperature(0.7)
                .build();

        String jsonResponse = openAiService.createChatCompletion(request)
                .getChoices().get(0).getMessage().getContent();

        return parseJsonToQuizList(jsonResponse, summary);
    }

    public String refineTimeFilteredTextWithFullContext(String timeFilteredText) {
        String similarSummary = qdrantClientService.searchSimilarSummary(timeFilteredText);
        String prompt = String.format("강의 전체 요약: %s\n\n아래는 수강생이 놓친 대사:\n%s\n\n이 구간을 복습용으로 다시 설명해 주세요.", similarSummary, timeFilteredText);

        ChatCompletionRequest request = ChatCompletionRequest.builder()
                .model("gpt-3.5-turbo")
                .messages(List.of(
                        new ChatMessage("system", "다음 텍스트를 복습용으로 정리하세요."),
                        new ChatMessage("user", prompt)
                ))
                .temperature(0.5)
                .build();

        return openAiService.createChatCompletion(request)
                .getChoices().get(0).getMessage().getContent().trim();
    }

    private String extractTopic(String input) {
        ChatCompletionRequest request = ChatCompletionRequest.builder()
                .model("gpt-3.5-turbo")
                .messages(List.of(
                        new ChatMessage("system", "자막 텍스트의 핵심 주제를 한 단어나 짧은 구로 추출하세요."),
                        new ChatMessage("user", input)
                ))
                .temperature(0.5)
                .build();

        return openAiService.createChatCompletion(request)
                .getChoices().get(0).getMessage().getContent().trim();
    }

    private List<AIQuiz> parseJsonToQuizList(String json, Summary summary) {
        ObjectMapper mapper = new ObjectMapper();
        List<AIQuiz> quizList = new ArrayList<>();
        try {
            List<Map<String, String>> rawList = mapper.readValue(json, new TypeReference<>() {});
            for (Map<String, String> item : rawList) {
                QuizType type = QuizType.valueOf(item.getOrDefault("quiz_type", "OBJECTIVE").toUpperCase());
                quizList.add(new AIQuiz(summary, type, item.get("quiz_text"), item.get("answer_text")));
            }
        } catch (Exception e) {
            System.err.println("❌ JSON 파싱 오류: " + e.getMessage());
        }
        return quizList;
    }
}
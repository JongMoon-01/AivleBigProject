package com.edtech.edtech_aiquizbackend.dto;

public class QuizResult {
    
}

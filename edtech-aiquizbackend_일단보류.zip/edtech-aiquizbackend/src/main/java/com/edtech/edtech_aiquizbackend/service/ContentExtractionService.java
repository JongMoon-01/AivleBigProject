package com.edtech.edtech_aiquizbackend.service;

import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.time.LocalTime;
import java.util.List;
import java.util.regex.Pattern;

import java.time.format.DateTimeFormatter;

@Service
public class ContentExtractionService {
    
    private static final DateTimeFormatter VTT_TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm:ss.SSS");

    public String extractByTimeRanges(InputStream vttInputStream, List<String> timeRanges) throws IOException {
    BufferedReader reader = new BufferedReader(new InputStreamReader(vttInputStream));
    List<String> vttLines = reader.lines().toList();

    StringBuilder selectedText = new StringBuilder();
    boolean insideBlock = false;

    LocalTime rangeStart = null;
    LocalTime rangeEnd = null;

    if (!timeRanges.isEmpty()) {
        String[] split = timeRanges.get(0).split("=");
        rangeStart = LocalTime.parse(split[0] + ".000", VTT_TIME_FORMAT); // 보정
        rangeEnd = LocalTime.parse(split[1] + ".000", VTT_TIME_FORMAT);
    }

    for (int i = 0; i < vttLines.size(); i++) {
        String line = vttLines.get(i);

        if (line.contains("-->")) {
            String[] times = line.split("-->");
            LocalTime startTime = LocalTime.parse(times[0].trim(), VTT_TIME_FORMAT);

            // ✅ 이 블록의 시작 시간이 지정 범위 안이면 추출 대상
            insideBlock = (rangeStart != null && rangeEnd != null && 
                           !startTime.isBefore(rangeStart) && !startTime.isAfter(rangeEnd));
        } else if (insideBlock && !line.isBlank()) {
            selectedText.append(line.trim()).append(" ");
        } else if (line.isBlank()) {
            insideBlock = false;
        }
    }

    return selectedText.toString().trim();
}

}
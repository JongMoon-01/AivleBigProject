package com.edtech.edtech_aiquizbackend.domain.summary;
import java.time.LocalDateTime;

import javax.persistence.*;

import com.edtech.edtech_aiquizbackend.domain.lecture.Lecture;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Summary {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long summaryId;

    private Long lectureId; // 외래 키처럼 사용

    private String userId;

    @Column(length = 255)
    private String topic;

    @Column(columnDefinition = "TEXT")
    private String content;

    private String time;  // 집중 안 한 시간 (raw string)

    private LocalDateTime createdAt = LocalDateTime.now();

}


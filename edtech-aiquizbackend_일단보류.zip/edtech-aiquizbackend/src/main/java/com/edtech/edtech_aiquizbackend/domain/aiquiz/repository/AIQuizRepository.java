package com.edtech.edtech_aiquizbackend.domain.aiquiz.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.edtech.edtech_aiquizbackend.domain.aiquiz.AIQuiz;

@Repository
public interface AIQuizRepository extends JpaRepository<AIQuiz, Long> {
}

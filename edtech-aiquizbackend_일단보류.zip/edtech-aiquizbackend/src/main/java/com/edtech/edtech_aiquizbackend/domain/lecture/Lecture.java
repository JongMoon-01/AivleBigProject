package com.edtech.edtech_aiquizbackend.domain.lecture;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Lecture {
    private Long lectureId;
}

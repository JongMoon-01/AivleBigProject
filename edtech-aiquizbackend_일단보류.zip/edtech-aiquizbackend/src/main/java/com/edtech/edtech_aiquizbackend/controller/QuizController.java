package com.edtech.edtech_aiquizbackend.controller;

import com.edtech.edtech_aiquizbackend.domain.lecture.Lecture;
import com.edtech.edtech_aiquizbackend.service.QuizGenerationService;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/quiz")
@RequiredArgsConstructor
public class QuizController {

    private final QuizGenerationService quizGenerationService;

    @PostMapping("/generate")
    public ResponseEntity<String> generateQuiz(
            @RequestParam("vttFile") MultipartFile vttFile,
            @RequestParam("timeRanges") List<String> timeRanges,
            @RequestParam("lectureId") Long lectureId,
            @RequestParam("userId") String userId
    ) {
        try {
            // 실제 Lecture 테이블에서 조회하지 않고, 단순 ID만 설정
            Lecture lecture = new Lecture();
            lecture.setLectureId(lectureId);  // 또는 setId()

            quizGenerationService.generateAndSaveQuiz(vttFile, timeRanges, lecture, userId);
            return ResponseEntity.ok("퀴즈 생성 완료");
        } catch (IOException e) {
            return ResponseEntity.internalServerError().body("파일 처리 중 오류 발생: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("에러 발생: " + e.getMessage());
        }
    }
}

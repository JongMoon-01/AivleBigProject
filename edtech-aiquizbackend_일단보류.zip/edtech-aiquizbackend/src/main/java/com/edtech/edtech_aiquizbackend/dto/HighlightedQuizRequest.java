package com.edtech.edtech_aiquizbackend.dto;

import lombok.Data;
import java.util.List;

@Data
public class HighlightedQuizRequest {
    private String vttFile; // 예: "korean_history.vtt"
    private List<String> timeRanges; // 예: ["00:01:20=00:07:30", "00:15:00=00:20:00"]
}

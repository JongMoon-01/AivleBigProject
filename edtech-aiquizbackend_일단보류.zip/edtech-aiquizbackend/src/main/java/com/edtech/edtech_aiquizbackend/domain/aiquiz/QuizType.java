package com.edtech.edtech_aiquizbackend.domain.aiquiz;

public enum QuizType {
    OBJECTIVE,
    SUBJECTIVE
}
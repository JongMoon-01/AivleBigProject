package com.edtech.edtech_aiquizbackend.domain.aiquiz;

import java.time.LocalDateTime;
import javax.persistence.*;
import lombok.*;
import com.edtech.edtech_aiquizbackend.domain.summary.Summary;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AIQuiz {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long questionId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "summary_id")
    private Summary summary;

    @Enumerated(EnumType.STRING)
    private QuizType quizType;

    @Column(columnDefinition = "TEXT")
    private String quizText;

    @Column(columnDefinition = "TEXT")
    private String answerText;

    private LocalDateTime createdAt = LocalDateTime.now();

    public AIQuiz(Summary summary, QuizType quizType, String quizText, String answerText) {
        this.summary = summary;
        this.quizType = quizType;
        this.quizText = quizText;
        this.answerText = answerText;
        this.createdAt = LocalDateTime.now();
    }
}


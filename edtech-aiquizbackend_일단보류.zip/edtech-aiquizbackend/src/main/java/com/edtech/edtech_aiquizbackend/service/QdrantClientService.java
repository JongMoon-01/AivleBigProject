package com.edtech.edtech_aiquizbackend.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.theokanning.openai.embedding.EmbeddingRequest;
import com.theokanning.openai.service.OpenAiService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
@RequiredArgsConstructor
public class QdrantClientService {
    private final OpenAiService openAiService;
    private final RestTemplate restTemplate;
    private final String QDRANT_URL = "http://localhost:6333";

    public float[] getEmbedding(String text) {
        EmbeddingRequest request = EmbeddingRequest.builder()
                .model("text-embedding-3-small")
                .input(List.of(text))
                .build();
        List<Double> embeddingList = openAiService.createEmbeddings(request).getData().get(0).getEmbedding();
        float[] embedding = new float[embeddingList.size()];
        for (int i = 0; i < embeddingList.size(); i++) embedding[i] = embeddingList.get(i).floatValue();
        return embedding;
    }

    public void upsertSummaryToQdrant(String summaryText) {
        float[] embedding = getEmbedding(summaryText);
        String id = UUID.randomUUID().toString();

        Map<String, Object> request = Map.of(
            "points", List.of(Map.of(
                "id", id,
                "vector", embedding,
                "payload", Map.of("summary", summaryText)
            ))
        );

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(request, headers);

        try {
            ResponseEntity<String> response = restTemplate.postForEntity(
                    QDRANT_URL + "/collections/summary/points?wait=true",
                    entity,
                    String.class
            );
            System.out.println("✅ Qdrant 업서트 응답: " + response.getBody());
        } catch (Exception e) {
            System.err.println("❌ Qdrant 업서트 실패: " + e.getMessage());
        }
    }

    public String searchSimilarSummary(String partialText) {
        float[] embedding = getEmbedding(partialText);

        Map<String, Object> body = Map.of(
            "vector", embedding,
            "limit", 1,
            "with_payload", true
        );

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(body, headers);

        try {
            ResponseEntity<String> response = restTemplate.postForEntity(
                QDRANT_URL + "/collections/summary/points/search",
                entity,
                String.class
            );
            ObjectMapper mapper = new ObjectMapper();
            JsonNode root = mapper.readTree(response.getBody());
            return root.path("result").get(0).path("payload").path("summary").asText();
        } catch (Exception e) {
            System.err.println("❌ Qdrant 검색 실패: " + e.getMessage());
            return "";
        }
    }
}

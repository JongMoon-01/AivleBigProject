// QuizGenerationService.java
package com.edtech.edtech_aiquizbackend.service;

import com.edtech.edtech_aiquizbackend.domain.aiquiz.AIQuiz;
import com.edtech.edtech_aiquizbackend.domain.aiquiz.repository.AIQuizRepository;
import com.edtech.edtech_aiquizbackend.domain.lecture.Lecture;
import com.edtech.edtech_aiquizbackend.domain.summary.Summary;
import com.edtech.edtech_aiquizbackend.domain.summary.repository.SummaryRepository;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class QuizGenerationService {

    private final ContentExtractionService extractionService;
    private final QdrantEmbeddingService embeddingService;
    private final SummaryRepository summaryRepository;
    private final AIQuizRepository aiQuizRepository;
    private final QdrantClientService qdrantClientService;

    public void generateAndSaveQuiz(
    MultipartFile vttFile,
    List<String> timeRanges,
    Lecture lecture,
    String userId
) throws IOException {

    // 1. 전체 VTT 텍스트 추출
    String fullText = new String(vttFile.getBytes());

    // 2. 전체 요약 Summary (FULL) → Qdrant에만 저장
    String fullSummaryText = embeddingService.generateSummaryOnly(fullText);

    // 3. TimeRange 텍스트 추출
    String timeFilteredText = extractionService.extractByTimeRanges(vttFile.getInputStream(), timeRanges);

    // 4. 퀴즈용 요약 생성 (Qdrant 벡터와 결합)
    String refinedSummaryContent = embeddingService.refineTimeFilteredTextWithFullContext(
        timeFilteredText
    );

    // 5. 퀴즈 생성 및 저장
    Summary quizSummary = new Summary();
    quizSummary.setLecture(lecture);
    quizSummary.setUserId(userId);
    quizSummary.setTime(String.join(",", timeRanges));
    quizSummary.setContent(refinedSummaryContent);
    quizSummary.setCreatedAt(LocalDateTime.now());
    summaryRepository.save(quizSummary);

    List<AIQuiz> quizzes = embeddingService.generateQuiz(refinedSummaryContent, quizSummary);
    for (AIQuiz quiz : quizzes) {
        quiz.setSummary(quizSummary);
        quiz.setCreatedAt(LocalDateTime.now());
        aiQuizRepository.save(quiz);
    }
}



}

import React from "react";

export default function HomePage() {
  return (
    <div className="flex items-center justify-center h-full py-24 text-gray-800 text-2xl font-medium">
      테스트용 메인화면입니다
    </div>
  );
}
